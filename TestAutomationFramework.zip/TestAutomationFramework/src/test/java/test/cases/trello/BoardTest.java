package test.cases.trello;

import api.BoardModel;
import api.TrelloApi;

import org.junit.Assert;
import org.junit.jupiter.api.*;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import pages.trello.BoardPage;
import pages.trello.BoardsPage;

import java.time.Duration;

import static com.telerikacademy.testframework.Utils.getUIMappingByKey;
import static com.telerikacademy.testframework.Utils.getWebDriver;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class BoardTest extends BaseTest {

    private BoardPage boardPage = new BoardPage(actions.getDriver());
    private BoardsPage boardsPage = new BoardsPage(actions.getDriver());
    private TrelloApi trelloApi = new TrelloApi();
    private BoardModel createdBoard;

    @Order(1)
    @Test
    public void createBoardWhenCreateBoardClicked() {
        login();

        boardsPage.createBoard();

        boardPage.assertListExists("To Do");

    }

    @Order(2)
    @Test
    public void createNewCardInExistingBoardWhenCreateCardClicked() {


        //Navigate to home
        boardsPage.navigateToPage();

        //Open board
        boardsPage.clickOnBoard(getUIMappingByKey("trello.boardsPage.boardByTeamAndName"));

        //add card to list
        actions.waitForElementClickable("trello.boardPage.firstList");
        boardPage.addCardToList(getUIMappingByKey("trello.cardName"));

        //Assert
        actions.assertElementPresent(getUIMappingByKey("trello.boardPage.cardCreated"));


    }

    @Order(3)
    @Test
    public void moveCardBetweenStatesWhenDragAndDropIsUsed() {

        String listTo = getUIMappingByKey("trello.boardPage.listTo");
        String cardToBeMoved = getUIMappingByKey("trello.boardPage.cardCreated");

        actions.dragAndDropElement( listTo, cardToBeMoved);

        //Assert


        actions.getElement("trello.boardPage.listByName", "Doing");
        actions.clickElement("trello.boardPage.cardByName","Card by Automation");
        actions.waitForElementPresent("trello.createdList.cardDetails");
        actions.assertElementPresent("trello.createdList.cardDetails");

    }

    @Order(4)
    @Test
    public void deleteBoardWhenDeleteButtonIsClicked() {

        //Navigate to home
        boardsPage.navigateToPage();
        //Open board
        boardsPage.clickOnBoard(getUIMappingByKey("trello.boardName"));

        boardPage.deleteBoard();

        //Assert
        
    }

}
