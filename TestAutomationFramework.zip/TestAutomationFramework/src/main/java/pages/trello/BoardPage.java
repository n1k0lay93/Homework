package pages.trello;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.security.Key;

public class BoardPage extends BaseTrelloPage {

    public BoardPage(WebDriver driver) {
        super(driver, "trello.boardPage");
    }

    public void addCardToList(String cardName) {

        actions.waitForElementVisible("trello.boardPage.listByName", "To Do");

        actions.clickElement("trello.boardPage.createListButton");

        actions.waitForElementVisible("trello.boardPage.addCardTextArea");
        actions.typeValueInField(cardName,"trello.boardPage.addCardTextArea");

        actions.clickElement("trello.boardPage.addCardButton");

    }

    public void moveCardToList(String cardName, String listName) {
    }


    public void assertListExists(String listName) {
        actions.waitForElementPresent("trello.boardPage.listByName", listName);
    }
    public void deleteBoard() {

        //Click the dropdown
        actions.waitForElementClickable("trello.boardPage.dropdownMenu");
        actions.clickElement("trello.boardPage.dropdownMenu");

        //Click close button
        actions.waitForElementClickable("trello.boardPage.dropdownClose");
        actions.clickElement("trello.boardPage.dropdownClose");

        //Wait for pop-up and Click close
        actions.waitForElementClickable("trello.boardPage.popUp");
        actions.clickElement("trello.boardPage.popUpClose");

        //Wait for delete and click
        actions.waitForElementClickable("trello.boardPage.deleteButton");
        actions.clickElement("trello.boardPage.deleteButton");

        //Wait for confirmation and click
        actions.waitForElementClickable("trello.boardPage.deleteConfirmation");
        actions.clickElement("trello.boardPage.deleteConfirmation");
    }
}
