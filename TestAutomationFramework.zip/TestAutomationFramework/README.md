**Instructions**
1. Clone repository
2. Open `TestAutomationFramework[test-automation-framework]` as a IntelliJ IDEA Project
3. Build
4. Run tests in `src\test\java\testCases`